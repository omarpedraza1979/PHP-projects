<?php

   $connection=  mysqli_connect('localhost','root','kiko.9732416','task_app1');

   /* if($connection){
        echo "Database is connected ";
    }*/

?>